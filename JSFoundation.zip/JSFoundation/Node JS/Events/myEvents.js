const EventEmitter = require('events');
const  eventEmitter = new EventEmitter();
eventEmitter.on("greet",(name)=>{
    console.log(`Hello ${name} this is node js events`);
})
eventEmitter.emit("greet","Aditya");
eventEmitter.once("pushNotify",()=>{
    console.log("this will run only one");
})
eventEmitter.emit("pushNotify");
const mylistener =()=> console.log("I am listener");
eventEmitter.on("test",mylistener);
eventEmitter.emit("test");
eventEmitter.removeListener("test",mylistener)
eventEmitter.emit("test");