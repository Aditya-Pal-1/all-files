const http = require('http');
const fs = require('fs');
const server = http.createServer(function(req,res){
    const method = req.method;
    const path = req.url;
    const log = `\n${Date.now()}  ${method}  ${path}`;
    fs.appendFileSync('log.txt',log,'utf-8');
    switch(req.method){
        case 'GET':{
            switch(path){
                case '/':{
                    return res.writeHead(200).end("Hello from the server");
                }
                case '/contact-us':{
                    return res.writeHead(200).end("you can contact me ");
                }
                case '/tweet':{
                    return res.writeHead(200).end("Tweet\n tweet2");
                }
            }
        }
        break;
        case 'POST':{
            switch(path){
                case '/tweet':{
                    return res.writeHead(201).end("Tweet has created");
                }
            }
        }

        return res.writeHead(404).end("You are lost");
    }
})

server.listen(5000);