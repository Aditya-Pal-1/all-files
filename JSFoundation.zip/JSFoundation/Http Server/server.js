const http = require('http');
// const server = http.createServer(function(req, res){
//     console.log('I got incoming calls');

//     res.writeHead(200);
//     res.end('Thanks for visiting the site');
// });

const server = http.createServer(function(req, res){
    console.log(`Incoming Call at : ${Date.now()}`);
    console.log(req.url);
    switch(req.url){
        case '/':
            res.writeHead(200);
            return res.end("HomePage");
        case '/contact-us':
            res.writeHead(200);
            return res.end("Contact me");
        case '/about':
            res.writeHead(200);
            return res.end("This is about page");
        default:
            res.writeHead(404);
            res.end("Not found");
    }
})

server.listen(8000, function(){
    console.log(`Server is ruuning at port 800`);
});