const express = require('express');


const app = express();

app.get('/',(req,res)=>{
    res.end("you are at homepage");
});
app.get('/contact-us',(req,res)=>{
    res.end("You can cantact us at gmaail.com");
});

app.post('/tweets',(req, res)=>{
    res.end("your tweets are posted");
});

app.listen(8000,()=>console.log('your server is running at port 8000'));