 exports.middleWare = function(req,res,next){
    console.log('Im a middleware !');
    next();
};