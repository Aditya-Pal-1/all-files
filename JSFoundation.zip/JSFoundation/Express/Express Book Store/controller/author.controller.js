const authorTable = require('../models/author.model');
const db = require('../db');
const { eq } = require('drizzle-orm');
const { v4: uuidv4 } = require("uuid");




exports.getAllAuthors= async function(req,res){
    const authors = await db.select().from(authorTable);
    return res.json(authors);
}

exports.getAllAuthorsById = async function (req, res) {
    const id = req.params.id;
    const author = await db.select().from(authorTable).where(eq(authorTable.id, id));
    return res.json(author);
}

exports.createAuthors = async function(req, res){
    const {firstName, lastName,email} = req.body;
    await db.insert(authorTable).values({
        id:uuidv4(),
        firstName,
        lastName,
        email,
    }).returning({
        id : authorTable.id,
    });
    return res.json({message : "Author has added"});
}