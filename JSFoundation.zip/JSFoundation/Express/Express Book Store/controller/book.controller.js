const bookTable = require('../models/book.model');
const authorTable = require('../models/author.model');
const db  = require('../db');
const {eq,sql} = require('drizzle-orm');
const { v4: uuidv4 } = require("uuid");

// const books = [];
// async function getAllAuthors(req,res){
//     const author = await db.select().from(authorTable);
//     res.json(author);
// }
// module.exports = {getAllAuthors,getAllBooks};
exports.getAllBooks =  async function (req, res) {
    const search = req.query.search;
    if(search){
        const book = await db
            .select()
            .from(bookTable)
            .where(sql`to_tsvector('english', ${bookTable.title}) @@ to_tsquery('english', ${search})`);
        return res.json(book);
    }
    const book= await db.select().from(bookTable);
    return res.json(book);
}

exports.getBookById = async function(req,res){
     const id = req.params.id;
     const [book] = await db.select().from(bookTable).where(eq(bookTable.id, id));

        if(!book){
            return res.status(404).json({Error : `Book does not exist with the id : ${id}`});
        }
        else{
            return res.status(200).json(book);
        }
}
exports.createBook = async function(req, res){
     const {title , description ,authorid} = req.body;
        if(!title || title === '') return res.status(404).json({Error :'Title is required'});
        const book = await db.insert(bookTable).values({
            id: uuidv4(),   
            title,
            description,
            authorid,
        }).returning({
            id : bookTable.id
        })
        return res.status(201).json({message: 'Book has added successfully' });
}
exports.deleteBookById = async function(req, res){
     const id = req.params.id;

     await db.delete(bookTable).where(eq(bookTable.id , id));

    return res.status(200).json({message:"Book has Deleted"});

}