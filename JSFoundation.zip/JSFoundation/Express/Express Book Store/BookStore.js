require('dotenv/config');
const express = require('express');
const bookRouter = require('./routes/book.routes')
const authorRouter = require('./routes/author.routes');
const {middleWare} = require('./Middleware/middleware');
const app = express();
const port = 8000;

app.use(express.json());
app.use(middleWare)

app.use('/books',bookRouter);
app.use('/authors',authorRouter);

app.listen(port,()=>console.log(`Http server is running at port : ${port}`));