const express = require('express');
const router = express.Router();
const authorController = require('../controller/author.controller');

router.get('/',authorController.getAllAuthors);
router.get('/:id',authorController.getAllAuthorsById);
router.post('/',authorController.createAuthors);


module.exports = router;