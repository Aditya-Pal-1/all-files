const express = require('express');
const router = express.Router();
// const books = require('../models/books');
const bookController = require('../controller/book.controller')

router.get('/',bookController.getAllBooks);
// router.get('/',bookController.getAllAuthors);

router.get('/:id',bookController.getBookById);

router.post('/',bookController.createBook);

router.delete('/:id',bookController.deleteBookById);
module.exports = router;