const authorTbale = require('./author.model');
const bookTable = require('./book.model');
module.exports ={
    authorTbale,
    bookTable
}