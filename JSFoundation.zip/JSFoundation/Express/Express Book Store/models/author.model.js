
const {pgTable,varchar,uuid} = require('drizzle-orm/pg-core');

const authorTable = pgTable('author',{
    // id:uuid().primaryKey(),
    id: uuid("id").defaultRandom().primaryKey(),
    // firstName : varchar({length : 255}).notNull(),
    firstName : varchar("firstName", { length: 255 }).notNull(),
    lastName : varchar("lastName", { length: 255 }),
    email : varchar("email",{length : 255}).unique()
});

module.exports = authorTable;
