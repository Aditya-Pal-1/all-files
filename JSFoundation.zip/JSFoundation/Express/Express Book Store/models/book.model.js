
const{pgTable,varchar,text,uuid,index} = require('drizzle-orm/pg-core');
const authorTable = require('./author.model');
const { v4: uuidv4 } = require("uuid");
const { sql } = require('drizzle-orm');
// const { index } = require('drizzle-orm/gel-core');

const bookTable = pgTable('book',{
    // id: uuid().defaultRandom().primaryKey(),
    id: uuid("id").defaultRandom().primaryKey(),
    // title:varchar({length : 255}).notNull(),
    title: varchar("title", { length: 255 }).notNull(),
    description :  text("description"),
    // authorid :uuid().references(()=>authorTable.id).notNull(),
     authorid: uuid("authorid").references(() => authorTable.id).notNull(),
},(table)=>({
    searchIndexOnTitle : index("title_idx").using("gin", sql`to_tsvector('english', ${table.title})`),
}));
module.exports = bookTable;
