function makeTea(teaType){
    function confirmOrder(){
        return `Order is confirmed`;
    }
    return confirmOrder();
}
let tea = makeTea("aditya");
console.log(tea);


const calculation=(price, quantity)=>{
    return price*quantity;
}
let total = calculation(2,4);
console.log(total);


function multiTea(checktea){
    return `${checktea}`;
}
function typeofTea(chai){
    return chai("this is chai");
}
let totalChai = typeofTea(multiTea);
console.log(totalChai); 


function fun1(name){
    return function(lastName){
        return `My Name is : ${name} ${lastName}`;
    }
}

let firstName = fun1("Aditya");
let complteName = firstName("Pal");
console.log(complteName);