const chatRoom = require('./chatRoom.js');
const chat = new chatRoom();
chat.on("join",(user)=>{
    console.log(`${user} has joined the chat`);
})
chat.on("message",(user,message)=>{
    console.log(`${user} : ${message}`);
})
chat.on("leave",(user)=>{
    console.log(`${user} has left the chat`);
})

// Simulating the response
chat.join("Alice");
chat.join("Bob");
chat.SendMessage("Alice","Hey Bob i am here");
chat.leave("Alice");