const {Buffer} = require('buffer');
// const buf = Buffer.alloc(5);
// console.log(buf);

const buf = Buffer.from("Aditya pal");
console.log(buf.toString());